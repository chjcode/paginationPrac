package com.ssafy.paginationpractice.domain.comment.dto;

public record CommentResponseDto(
//        Long id,


) {

}
